from models import Todo_task
from django.contrib import admin

admin.site.register(Todo_task)